# Culinera — update the built Image Repair screen (preview only)

**How to use this:** Copy everything between **BEGIN REQUEST** and **END REQUEST** into Emergent. This is a request to develop and test the existing tool, not to deploy it or change production. No terminal, API key, or backend repository access is needed from you.

## BEGIN REQUEST

Please update the **existing, already-built Image Repair admin screen** and its backend/ingestion support. Keep this work **in preview only**. I approve developing the changes below; I have **not** approved deployment, production repairs, or publication. After testing, send me the preview link and results and wait for my separate, explicit deployment approval.

Your latest reply says the screen is built and tested at:

https://seo-phase.preview.emergentagent.com/admin

It also reports that `seo-phase.emergent.host` and `culinera.ca` use the same deployed backend/database, returning 190 published records with the 20 manifest records present, while preview uses a separate `culinara_db` with 166 records and none of those 20. Treat these as your previously reported observations, not permanently guaranteed counts. **Do not point preview at production, copy production credentials into preview, change scraper targets/domains/secrets, or deploy merely to test the real 20.** Use isolated preview fixtures for testing missing production records and clearly label them as fixtures, not completed repairs.

### 1. The three confirmed policy changes

1. **Official establishment photos can enter manual review with rights UNVERIFIED.** A photograph on the establishment's verified own website or official account is a candidate, not proof of ownership or permission. Allow safe, relevant candidates to be staged without inventing a licence, rights holder, author, or `permission_basis`. An admin may explicitly acknowledge unverified rights and manually apply an otherwise valid candidate, while its rights status stays `unverified`. Do not make them tick a false “I own this image / this image is licensed” box.
2. **Fallback: a free, explicitly licensed photograph of a literal, confirmed menu dish.** If a suitable actual-establishment photo is unavailable, allow an external photograph of the specific dish independently confirmed on that establishment's menu, with a recorded licence permitting our actual commercial display, download/rehosting, and any transformations. Label it clearly as illustrative in admin previews and public cards. It must not imply that the photograph depicts that restaurant's own food.
3. **Reject duplicates against readable existing images and the same batch, but do not globally stop review because some legacy images are unreadable.** Keep incomplete coverage honest. Allow unresolved comparisons only with a separate manual acknowledgement and audit record; never allow that acknowledgement to override an actual duplicate or another hard validation block.

These rules apply to **both the 20 old published-record repairs and future pending cards**. Every image application requires manual admin approval. New-card publication remains a separate manual approval action; nothing is automatically published.

This update supersedes the old manifest's stricter permission-only, actual-venue-only fallback, and globally complete duplicate-check gates **only as explicitly described here**. Preserve the original manifest/report as immutable references; do not silently rewrite their history or label new manual-risk acceptance as the old `repaired_verified` standard.

### 2. Update the point-and-click review screen

Keep the existing manifest rows, exact record ID/name/city, current image, side-by-side duplicate display, Stage, Apply replacement, Restore previous image, progress badges, and Download results (JSON). Add the same review panel to new pending cards.

Show three independent areas: **technical/relevance validation**, **rights status**, and **duplicate coverage**. Do not collapse them into one “permitted/unique/approved” badge.

Use these exact rights values:

- `unverified` — show **UNVERIFIED — reuse rights not established**.
- `source_licence_recorded` — the applicable exact-photo licence and its evidence are recorded; this is not an ownership or legal-guarantee claim.
- `permission_documented` — an applicable permission document/evidence reference is recorded; this is not necessarily ownership.

Use a separate `review_decision`: `pending`, `approved`, or `rejected`. A manually approved photo may still have `rights_status: "unverified"`. Approval must never change it automatically to either evidence-backed status. Separate restaurant publication status from image review status. `rights_review_required` describes outstanding rights review, not a licence: it remains `true` for unverified rights even after an admin acknowledges the risk.

For official-source unverified candidates, show this unchecked acknowledgement immediately before **Apply replacement / Apply image to pending card**:

> I understand that reuse rights for this photograph are UNVERIFIED. Its presence on the establishment's official website/account and any photographer credit do not prove ownership or permission to reuse, download, rehost, or publish it. I choose to apply this image with that uncertainty recorded and accept the legal risk. This is not a declaration that I own the photograph or that it is licensed.

For incomplete duplicate coverage, show a **different** unchecked acknowledgement:

> I understand that this image was checked only against the readable/indexed images listed in the coverage report and this batch. The listed missing or unavailable comparisons remain unresolved, so global uniqueness is not confirmed. I choose to proceed with this limitation recorded.

Neither acknowledgement is preselected. Neither can be submitted by an ingest client as an authenticated admin decision. Changing the candidate bytes, rights evidence, relevance mapping, or material duplicate report invalidates the corresponding prior approval/acknowledgement and requires renewed review. Log each decision using the authenticated admin's **server-derived ID** and **server timestamp**, the exact acknowledgement text/version, candidate identity/hash, report snapshot, and action. Do not trust client-supplied reviewer IDs or approval timestamps.

Require a valid `source_page_url` for every candidate, including uploads. Keep the original direct photo URL when known; an uploaded file may have no original URL, which must remain null/empty rather than invented. Unknown rights holder and photographer stay null/empty; render “Unknown” in the UI. Preserve known photographer credit, but **credit is not permission**. A helper may copy a verified official source into the source-page field, but must not infer rights ownership or fabricate permission evidence. Do not force a nonempty licence/permission basis for an unverified official-source candidate.

Known restrictions are not merely unknown rights. Retain restriction evidence and show it. **Reject a third-party fallback whose terms prohibit the required use**: no CC BY-NC/commercial-use conflict, CC BY-ND/incompatible adaptation, forbidden rehosting, or other known incompatibility can be overridden with either acknowledgement. Do not relabel a known restriction as `unverified` to pass. An official-source candidate with a known applicable prohibition may remain held for further review, but applying it requires a documented applicable exception/permission; the unknown-rights acknowledgement is not a bypass. A generic copyright notice is not a reuse licence and must not be presented as one. Keep any actual known terms alongside it. No claim of legal certainty, guaranteed compliance, or immunity from claims.

After application/publication, retain the truthful unverified-rights warning in admin review and results exports. Public cards must retain required source/credit/licence information and the conspicuous illustrative caption where applicable; do not claim an unverified image is licensed. Publish only non-sensitive provenance. Permission documents, private correspondence, reviewer account IDs, and internal audit details remain admin-only.

### 3. Relevance and illustrative fallback

Actual-establishment photos must match the exact establishment **and branch/location**, not just its name or brand. Official publication does not prove a photograph depicts the particular branch or dish; review that independently. No AI image, invented food, unrelated generic cuisine, misleading stock photograph, or wrong-location substitute.

For `illustrative_menu_dish`, require:

- The literal dish name and a menu evidence URL plus a short evidence quote/date that confirms the dish for the correct establishment/location. The old card description or cuisine tag alone is not menu confirmation.
- A real photograph showing that dish, not merely a related cuisine or ingredient.
- An explicit applicable free licence/source grant, exact-photo source page, licence URL and evidence, required credits/notices, and conditions covering the intended use and transformations. Meet attribution/share-alike/change-notice conditions where applicable; do not label “royalty-free” marketing language alone as permission.
- A required caption: **“Illustrative photo of [confirmed dish]; not photographed at [establishment name].”** Show it conspicuously in both the pending preview and public card; do not rely solely on alt text or a tooltip. Include accurate credit, source, licence link and change notice as required. Do not alter the restaurant description to pretend this is its actual dish photograph.

If identity, dish, licence, or image suitability cannot be established, keep the candidate unresolved. No qualifying replacement photograph is supplied by this request. The existing evidence file records **zero delivered/downloaded photographs and zero working free-reuse candidates**, not 20 photos ready to apply. Older source leads can inform review but are not fresh validated image files or approvals.

Important identity holds from that evidence:

- `miner-s-cafe-abc0` is recorded as **Miner's Cafe, Canmore**. The found `https://www.minerscafe.ca/` identifies **Nordegg**, not Canmore. Do not stage/map a Nordegg photo as a valid Canmore replacement or silently change the city/name. Keep identity unresolved until independently confirmed.
- `station-park-food-hall-eefd` is **Station Park Food Hall, Edmonton**, with an old `https://www.epicmarket.ca/` image/source URL. Evidence identifies the current food hall at **8115 Gateway Boulevard** through `https://stationparkfoodhall.com/`; EPIC reports its Whyte Avenue location closed and seeking a new home. Do not blindly use EPIC photos or infer the historical tenancy relationship as proof of current identity. Verify the exact current venue/photo. Preserve the legacy EPIC URL in history, not as a falsely validated current photograph, and do not change unrelated restaurant fields under an image repair.

### 4. Honest duplicate indexing, security, and application

Please correct the earlier statements that clicking **Build duplicate index** makes checks “fast and complete” or “fully confirms” uniqueness. It builds the **available** index; it cannot fingerprint HTML profile links, inaccessible images, unindexed images, or inventory not supplied to it.

Decode actual candidate bytes and compute **exact SHA-256 plus perceptual image pHash**. Compare with readable/indexed published images, accessible pending images, known accessible retained image history, and every current same-batch candidate (including a second candidate before staging it). URL differences do not prove uniqueness. Report the actual pHash algorithm/version/bit length, Hamming-distance threshold, matched record/candidate IDs, distances, and visual side-by-side comparison. Exact duplicates and confirmed perceptual duplicates across distinct cards/candidates are hard blocks with no risk-acknowledgement override. A near-match needing visual adjudication stays held until an admin confirms it is a false positive with a recorded reason; that is not an override of a confirmed duplicate. Do not treat the same candidate attached to its own record as a cross-card conflict.

For each candidate and summary, show **compared count, missing/not-indexed count, remaining URLs with reasons**, published/pending/history counts and coverage scope, same-batch compared count, and unknown inventory explicitly. Reconcile counts by image instances and identify repeated URLs separately. `duplicate_coverage_complete` is `false` if **any known published or pending image is unreadable or unindexed**, required same-batch comparison is missing, or the claimed inventory cannot be established. Also account explicitly for missing known history when history is included in the stated scope. Unknown private/pending/history inventory is **unknown, not zero**. A fully indexed returned public subset may be described as complete **for that subset only**, never as globally complete without all required inventory. Show which inventory was provided, when the snapshot/index was built, and what could not be accessed. Do not expose private pending details publicly.

An incomplete report alone does not block every otherwise valid image. Allow per-candidate manual acknowledgement, retain `duplicate_coverage_complete: false`, and export that limitation. Do not blank/null old image URLs, hide restaurants, delete records, or force old images to placeholders to manufacture completeness. Rebuild/recheck immediately before apply; stale reports and concurrent batch changes must not allow duplicates through. Enforce cross-card/same-batch duplicate blocking server-side, including concurrent applies.

**Never relax safety to implement either exception.** Apply the same server-side URL protections to source-page validation/fetches, direct image fetching, redirects, and source-image fallback: HTTP(S) only; block localhost/private/link-local/reserved networks and cloud metadata endpoints, including IPv6, DNS rebinding and redirect targets; enforce redirect, timeout, response-size and decoded-pixel limits. A source page may be HTML provenance, but an `image_url`/photo candidate must be a safely fetched, supported real image, not that HTML page. HTTP 200, a filename extension, or HEAD alone is insufficient. Require actual GET, accepted MIME/content validation, successful full decoding and decoded dimensions; reject unsafe active formats/content, corrupt files, login/challenge/error pages and unsafe URL schemes. A manual acknowledgement cannot bypass these blocks, identity/relevance failures, or incompatible known restrictions.

Stage validated candidate bytes in isolated preview/staging storage without changing the restaurant's live `image_url`. Retain original-photo SHA-256/pHash/dimensions and fetched-at timestamp, plus hashes/dimensions for any transformed display rendition. At manual apply, obtain/validate a fresh source file when URL-sourced, or the immutable validated upload bytes when upload-sourced. If the source changed, require renewed candidate review; do not silently swap photographs. Rehost the approved file in **durable Culinera-controlled storage**, record the durable object reference/URL, and validate the publicly readable stored image with actual GET/MIME/decode. No temporary sandbox URL, expiring image URL, social profile URL, or webpage may become the final published `image_url`.

Keep the backend's **single restaurant `image_url`** as the canonical display field; store original/source/storage/provenance separately. In the admin frontend, display the safe validated candidate source or staging image before apply, and the durable image after apply. If implementing an image-load fallback, use only that candidate's separately validated, review-eligible source image or approved durable rendition, with no loop and no generic invented replacement. Keep credit, licence, unverified warning and illustrative caption intact when image loading fails or falls back. On public cards, prefer the durable approved image; never expose an unapproved pending candidate or mistake a source-page link for an image. Render captions, credit, attribution quotes and change notes as escaped **plain text**, not injected HTML; validate separately rendered source/licence links. Include the illustrative caption in the before-publication card preview.

Before any eventually authorized production repair, make a restorable record/image/provenance backup using authorized backend access. Re-read the exact ID and expected current image/status before a transactional update; do not overwrite concurrent unrelated changes. Preserve **ID, name, city, status, existing `source`, unrelated fields, and legacy source URL/history**. No insert/delete/merge/rename/status change through repair. Retain the prior storage object and previous image/provenance so Restore previous image can undo the image-only update without undoing later unrelated edits. A published record stays published; a pending record stays pending. An image-only apply is not a publication action.

For the 20 manifest rows, add **Suggest / stage candidate batch for manual review**, not “apply all automatically.” Suggestions must provide a real validated candidate and evidence, or a concrete unresolved reason. Do not invent 20 photographs, silently map identity holds, or mark “Repaired” merely because the tool was built. If several photos are staged, each still needs its own manual application/decision. Report actual counts: no photo, staged, blocked, manually applied, rolled back; keep rights and uniqueness limitations alongside these states. “Applied with unverified rights/incomplete coverage” must not be described as globally duplicate-free, fully licensed, or fully verified.

### 5. Backend persistence and backward-compatible scraper contract

This is **not frontend-only**. Preserve these fields through validation, persistence, admin edits, JSON export, and appropriate public serialization. In particular, **`POST /api/ingest/restaurants` must not silently drop `image_review`, `rights`/licence metadata, `image_caption`, or `image_licence_url`.** New cards with flagged unverified metadata may enter the pending review workflow; they must never automatically receive approved image review or published restaurant status. Technical failures remain blocked from being applied/published; rejected/unsafe metadata must not be disguised as a validated photo.

**Actual implemented scraper contract:** The attached `SCRAPER_IMAGE_CONTRACT.json` defines the current client schema **1.2**. Its `image_review` fields are flat (`rights_status`, `rights_holder`, `licence_name`, `licence_url`, `licence_evidence`, `source_page_url`, `source_image_url`, `photographer_credit`, `is_illustrative`, `caption`, `menu_evidence`, `client_duplicate_check`, hash/dimension fields, and `review_decision: "pending"`). Treat the larger 1.1 dictionary below as a proposed backend storage structure, not the actual incoming client shape. Implement and document a lossless mapping from the attached 1.2 client fields. Do not silently discard unknown metadata or treat it as admin approval. The current client caption is "Illustrative image — not photographed at this venue"; you may render the more specific dish/venue caption described above from its real menu evidence.

The scraper maintainer owns scraper code, not your backend repository. Implement the backend/admin changes on your side and return the accepted request/response shape and field mapping so the maintainer can adapt the scraper. The nested dictionary below is a **proposed contract**, not a claim that the scraper already emits it. Adapt existing backend names if necessary, but provide one explicit lossless mapping rather than parallel conflicting fields. Do not require the scraper maintainer to modify your repository or receive secrets.

Backward compatibility: existing ingestion payloads without these optional fields still work under existing manual-pending behavior. Default absent image-review metadata to `pending`, never infer permission from an existing URL or infer prior approval. Legacy public records remain unchanged until manually repaired. New ingestion cannot impersonate an admin, set a server approval, promote rights without evidence, or publish by supplying `review_decision: "approved"`; reject or normalize such privileged inputs explicitly and document the response. Server-recompute hashes/technical validation/duplicate coverage rather than trusting scraper attestations. Do not change production API keys or include any in the handoff.

#### Proposed schema / field contract

The following is a **shape example**, not an executable submission or an actual candidate. Replace nulls only with real information. Existing restaurant fields continue alongside it.

```json
{
  "image_url": null,
  "image_caption": null,
  "image_licence_url": null,
  "image_review": {
    "schema_version": "1.1",
    "candidate_id": null,
    "candidate_image_url": null,
    "image_kind": "actual_establishment",
    "source_kind": "official_establishment",
    "source_page_url": null,
    "original_photo_url": null,
    "original_legacy_image_url": null,
    "rights_status": "unverified",
    "rights_review_required": true,
    "rights": {
      "rights_holder": null,
      "photographer_credit": null,
      "credit_text": null,
      "licence_name": null,
      "licence_url": null,
      "licence_evidence_quote": null,
      "licence_evidence_ref": null,
      "permission_evidence_ref": null,
      "permission_basis": null,
      "allowed_uses": [],
      "restrictions": [],
      "change_notice": null,
      "expires_at": null
    },
    "relevance": {
      "record_id": null,
      "establishment_name": null,
      "city": null,
      "branch_address": null,
      "identity_evidence_url": null,
      "decision": "pending",
      "confirmed_menu_dish": null,
      "menu_evidence_url": null,
      "menu_evidence_quote": null,
      "menu_evidence_checked_at": null
    },
    "validation": {
      "status": "pending",
      "final_source_photo_url": null,
      "fetched_at": null,
      "mime": null,
      "decoded_format": null,
      "width": null,
      "height": null,
      "source_sha256": null,
      "source_phash": null,
      "phash_algorithm": null,
      "phash_bits": null,
      "phash_distance_threshold": null,
      "display_sha256": null,
      "display_phash": null,
      "display_width": null,
      "display_height": null,
      "errors": []
    },
    "duplicate_coverage_complete": false,
    "duplicates": {
      "result": "unresolved",
      "scope_label": "inventory not yet established",
      "inventory_scope_complete": false,
      "checked_at": null,
      "index_version": null,
      "published_returned_count": null,
      "published_image_count": null,
      "pending_inventory_known": false,
      "pending_record_count": null,
      "pending_image_count": null,
      "history_inventory_known": false,
      "history_image_count": null,
      "compared_count": 0,
      "missing_count": null,
      "same_batch_candidate_count": null,
      "same_batch_compared_count": 0,
      "remaining_urls": [],
      "unknown_inventory": ["pending", "history"],
      "matches": []
    },
    "review_decision": "pending",
    "admin_review": {
      "admin_id": null,
      "decided_at": null,
      "candidate_sha256": null,
      "rights_unverified_acknowledged": false,
      "rights_acknowledgement_text_version": null,
      "duplicate_incomplete_acknowledged": false,
      "duplicate_acknowledgement_text_version": null,
      "coverage_snapshot_ref": null,
      "audit_event_ref": null
    },
    "storage": {
      "durable_image_url": null,
      "durable_object_ref": null,
      "stored_at": null,
      "backup_ref": null
    }
  }
}
```

Schema rules:

- `image_kind` is `actual_establishment` or `illustrative_menu_dish`; `source_kind` is `official_establishment`, `third_party_licensed`, or `admin_upload`. An upload does not itself prove permission or relevance. An illustrative upload still needs the fallback's licence/menu evidence.
- `rights_status` uses only `unverified`, `source_licence_recorded`, `permission_documented`. Evidence-backed values require applicable real evidence. `review_decision` is independently `pending`, `approved`, `rejected`. `validation.status` is `pending`, `valid`, `invalid`; `relevance.decision` is `pending`, `confirmed`, `rejected`; `duplicates.result` is `unresolved`, `clear_in_compared_scope`, `duplicate`, `near_match_review_required`.
- `candidate_id`, validated technical results, computed coverage, authenticated review fields, storage and backup references are server-owned. Ingest may send candidate/evidence information, not trusted approvals or computed clearance. Preserve useful scraper observations as untrusted observations if needed; do not treat them as backend validation.
- A candidate cannot be staged as valid/applied without a valid source-page URL, safely decoded real image, and required relevance evidence. Unverified official-source candidates may have empty rights holder, credit, licence and permission fields. Do not substitute the venue name for an unknown photographer/holder.
- Fallback requires `image_caption`, confirmed dish/menu evidence and compatible recorded rights evidence; `image_licence_url` must persist and agree with `image_review.rights.licence_url` when a licence applies. One canonical value may back both views; never lose it in model serialization.
- `remaining_urls` entries include `{ "record_id": null, "scope": "published", "url": null, "reason": "not_indexed" }` with real values when known. `missing_count` is the known unexamined image-instance count for the stated scope; use null if not established. Empty lists alone are not proof of completeness. Unknown total inventory remains separately visible even when known missing count is zero.
- `matches` entries include record/candidate ID, scope, exact-match flag, pHash distance, and adjudication/reason where relevant. Preserve actual algorithm settings and the coverage snapshot in the audit/export.
- Ingest returns a persisted pending record/candidate plus its review state and validation warnings. Authorized admin reads expose full review metadata; public reads expose only approved display metadata, source/credit/licence/caption and applicable rights warning. Do not leak private pending inventory, permission documents or reviewer identity.

### 6. Required preview acceptance tests and handoff

Run these against the **built admin screen and corresponding backend in isolated preview**, not only unit-test helpers. Return actual pass/fail results and screenshots or test evidence, label fixture counts separately, and leave failed cases unresolved. Do not claim these tests have already passed simply because the earlier version was built.

- **Environment isolation:** preview still uses its separate DB; the 20 real manifest records show “Not in this database” unless represented by clearly labelled preview fixtures. No production requests/writes, domain retargeting, secret changes, deployment, or publication were performed for this update.
- **Official unverified flow:** a safe, location-confirmed official-source fixture with empty holder/credit/licence/permission fields stages as UNVERIFIED. Apply requires the exact unverified acknowledgement; the server records admin ID/time and `approved` independently while rights stay `unverified` and rights review remains required. No fake ownership/licensing checkbox or fabricated credit is necessary. Cancelling leaves the record unchanged.
- **Evidence-backed and known-restriction flow:** genuine applicable licence/permission evidence persists and displays correctly. Known incompatible third-party restrictions, including NC/commercial conflicts and ND/incompatible transformations, block fallback apply even with acknowledgements. An official source with an applicable explicit prohibition is held without an applicable exception/permission; unknown-rights acceptance cannot erase known evidence.
- **Literal dish fallback:** an explicitly free-licensed photo of a confirmed menu dish stages and displays the required illustrative caption, credit/source/licence/change notice before publication. A merely similar cuisine, unconfirmed dish, wrong branch, brand-only image, AI image, or invented menu evidence is rejected/held. Publishing manually later preserves the conspicuous illustrative label.
- **Identity holds:** the Canmore Miner's Cafe fixture cannot be “repaired” using Nordegg identity/photos; Station Park cannot silently inherit closed EPIC imagery. Image repair does not rename either restaurant, change its city/status/source, or mark unresolved identity as repaired.
- **Exact/perceptual duplicates:** identical bytes under different URLs and resized/recompressed near-duplicate fixtures are detected against readable published/pending images and same-batch candidates. Show real SHA-256/pHash/dimensions, comparison counts, algorithm/threshold and side-by-side matches. Confirmed duplicates cannot be applied by either acknowledgement; near-match false positives require recorded visual adjudication. Concurrent stage/apply requests cannot bypass same-batch/cross-card checks.
- **Incomplete coverage:** one unreadable or unindexed known published/pending image keeps `duplicate_coverage_complete: false` after Build duplicate index. Show compared/missing counts and remaining URLs/reasons. Missing private inventory remains unknown, not zero or global clearance. A unique-in-compared-scope valid candidate can apply only after the separate incomplete-coverage acknowledgement; an actual duplicate still cannot. No old URL is blanked, no card hidden/deleted, and no “fully confirmed” claim appears.
- **Safety cannot be acknowledged away:** private-network/metadata/IPv6 targets, redirect-to-private and DNS-rebinding cases, unsafe schemes, HTML returned as a photo, login/challenge pages, corrupt/unsafe images and over-limit files fail server-side. Source-page provenance is not confused with a direct photo. MIME/decode/dimensions are based on actual bytes, not HEAD, extensions or HTTP 200 alone.
- **Ingestion round trip:** `POST /api/ingest/restaurants` with proposed review/rights/caption/licence fields persists them; admin GET, edit, export and later approved public serialization retain the appropriate values. Flagged unverified candidates enter pending only. Old payloads still work. Client-supplied approval/admin ID/timestamp/duplicate-clearance does not approve or publish. Show the accepted schema mapping and response, without keys/secrets, for the scraper maintainer.
- **Manual gates for both workloads:** Stage/suggestion batch does not change the canonical live image, approve a candidate, or publish a restaurant. Each of the 20 repair fixtures and each new pending fixture needs its own manual image application; pending stays pending until separate authorized manual publication. No automatic “apply all,” approval, or publication path exists.
- **Durable image/rendering and rollback:** manual apply uses reviewed bytes, rechecks changed sources/concurrent duplicates, writes one canonical durable `image_url`, and verifies actual stored GET/MIME/decode. Original source URL, legacy URL, hashes/dimensions, safe provenance, caption and licence survive. Image fallback/loading failure keeps credit/caption/rights warnings intact and uses no unapproved or unrelated substitute. Plain-text attribution/XSS tests render escaped text and reject unsafe links. Restore previous image restores prior image/provenance only; ID/name/city/status/source/unrelated edits remain intact.
- **Truthful completion and next action:** export actual no-photo/staged/blocked/applied/rollback counts, perceptual-comparison coverage and remaining URLs/unknowns; show UNVERIFIED and incomplete warnings after application/publication as appropriate without exposing private evidence. Do not report “20 photos found,” “20 repaired,” licensed ownership, or global uniqueness without corresponding evidence. **Send the tested preview link and test results; do not deploy. Wait for my separate explicit deployment approval.**

## END REQUEST

## Readiness gate for later live ingestion

The replacement workflow passes the non-secret GitHub variable `IMAGE_REVIEW_FIELDS_ENABLED` to the script. It defaults to false; preview runs still work. Before a live pending-queue run, demonstrate that the deployed endpoint retains the actual 1.2 metadata and renders the required review warnings, attribution and illustrative labels. Then tell the user it is safe to set that variable to `true`. Do not set it on their behalf, do not change any secrets, and do not enable `LIVE_SUBMISSIONS_ENABLED` or deploy without separate explicit approval. This readiness gate prevents sending captions/warnings into an old endpoint that silently drops them.
