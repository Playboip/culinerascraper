# Culinera: practical image-review update

Prepared files, not a production deployment. No restaurant record has been submitted, repaired or published by this task.

## What you approved

The scraper now tries the verified establishment's own website and menu-page photographs first. These are labelled **unverified rights — admin review required**; it does not fabricate a licence or claim you own them.

If no suitable official photo works, it may use a free Wikimedia Commons photograph of a dish explicitly evidenced on that venue's menu. It records the source's CC BY/CC0 licence evidence, required credit and an **illustrative image — not photographed at this venue** caption. If the dish, licence, image content, working image file or uniqueness checks fail, the candidate remains held. The source's licence metadata is evidence, not a legal guarantee.

Known duplicate URLs and visually matching pHashes are rejected against readable/cached existing images and the current batch. Unreadable old images no longer block the entire queue. Full private pending inventory is unavailable to the scraper, so its coverage is explicitly incomplete; Emergent's authenticated admin checks must supplement it. There is no false claim of zero duplicates against images that cannot be compared.

Wrong-branch checks, real-business rules, 4.0 stars/10 reviews or verified-new-opening exception, verified food trucks, original description checks, pending-only ingestion, safe previews and twice-monthly scheduling remain intact. Image sourcing has no photo fees, but your existing Google/OpenAI/API usage can still incur charges.

## Step 1 — Send the update to Emergent

Attach `EMERGENT_IMAGE_REVIEW_UPDATE.md` and `SCRAPER_IMAGE_CONTRACT.json` in your existing Culinera Emergent conversation. Say:

> Please implement the confirmed image-review changes in preview, including the actual scraper metadata contract attached. Official-source photos may be staged with rights marked unverified, not fabricated permission. Keep duplicate warnings honest, and label licensed menu-dish illustrations. Include candidate suggestions for the 20 old records for my manual review. Do not deploy or apply images automatically. Return the tested preview link and confirm ingestion preserves every required metadata field.

The existing screen is still preview-only. The 20 live records are not in the preview database. Testing with isolated preview fixtures is not a production repair. Do not give the agent keys in normal chat; it owns its backend environment.

## Step 2 — Replace the active GitHub files, not `(1)` copies

Open https://github.com/Playboip/culinerascraper on branch **main**.

Four essential files belong directly in the repository root:

1. `alberta_culinary_scraper.py`
2. `free_dish_photos.py` (NEW dependency: must be uploaded too)
3. `test_pipeline.py`
4. `test_branch_matching.py` (previously missing from main)

Also upload the included `test_image_review.py` and `test_free_dish_photos.py` so the new rules are regression-tested on GitHub.

**Before upload:** if Windows added `(1)`, `(2)` or similar to a name, rename it to the exact filename above. A file called `alberta_culinary_scraper (1).py` does NOT replace `alberta_culinary_scraper.py`.

Use **Add file → Upload files**, choose those six individual Python files and **Commit changes** directly to main. Do not upload the ZIP itself or an enclosing `scraper/` folder. Keep existing `image_guard.py`, `scrapling_discovery.py`, `sources.json`, `requirements.txt`, provider tests, source tests and all secrets.

If you use the complete `scraper/` directory from the ZIP, its contents are the repository root files; `scraper` itself must not become a nested directory in GitHub. The archive includes the required unchanged helpers and dependencies as well as the updates.

## Step 3 — Update the ONE existing workflow

Open `.github/workflows/main.yml` on GitHub. Click the pencil/edit button. Replace the contents with the supplied `main.yml` / `WORKFLOW_COPY_PASTE.txt` contents. Commit the change. Do not create a second workflow or save it to the repository root.

This keeps the 1st-and-15th schedule and existing secret names. It adds one repository-variable environment field for metadata readiness. Scheduled runs stay previews while live submissions are locked.

No new API key or paid image service is required.

## Step 4 — Preview only before any live submission

Once the files are uploaded, tell Manus `image-review update uploaded`. Manus can verify the public file contents and filenames without running the scraper.

Start a **NEW** workflow on main, not Re-run jobs on an old commit, with:

- `dry_run`: checked
- `discovery_only`: unchecked
- `scan_all_alberta`: unchecked

API charges may apply. Download the new `culinera-scrapling-report-…` ZIP and send it to Manus. This does not submit or publish anything.

It is now possible to prepare a card despite old unreadable images; it is NOT guaranteed every discovered venue will have a suitable image, verified address or original description. Wikimedia service blocks and missing menu evidence remain explicit hold reasons. Do not keep rerunning if the report shows a configuration or source blocker.

## Step 5 — Later, after preview and backend deployment approval

Do not approve production deployment or enable live submissions merely because tests passed locally. Emergent must first demonstrate that its backend/admin tool preserves `image_review`, source/credit, rights status, licence evidence and the illustrative caption, and that manual acknowledgements cannot be impersonated by an ingest request. You then authorize deployment separately.

After the deployed endpoint is confirmed to retain this metadata and a preview report is reviewed, enable the repository variable `IMAGE_REVIEW_FIELDS_ENABLED` with value `true`. This is a non-secret variable, not an API key. Keep `LIVE_SUBMISSIONS_ENABLED` false until you expressly choose a live pending-queue run.

The new readiness check intentionally prevents a live submission into an old backend that would silently discard the image warnings and captions. Preview runs work without this variable being enabled.

## Old image repairs

The scraper itself never updates published restaurant records. Emergent's admin screen stages relevant candidates for the 20 exact IDs, flags unknown rights/incomplete duplicate coverage, then requires your explicit manual application. Backups, rollback and publication statuses remain intact.

Miner's Cafe's Canmore/Nordegg identity issue and Station Park Food Hall's EPIC source mismatch must remain held for identity review, not be silently patched with another venue's photograph. The original manifests/reports remain historical evidence; they are not rewritten to manufacture successful repairs.
