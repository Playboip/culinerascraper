# Copy this request to your Emergent agent

Please make the existing Culinera discovery/admin pipeline reliable for a new external Scrapling crawler. Do not build another crawler inside this app and do not auto-publish anything.

1. Rotate the previously exposed INGEST_API_KEY. Set the replacement in the deployed backend and help me set the same replacement in my GitHub Actions secret. Do not post the replacement publicly.

2. Inspect every existing restaurant image_url. Some previous records used webpage/Instagram URLs instead of actual image files. Repair those records by obtaining an authorized real venue photo or a manual owner-provided/uploaded photo; do not substitute a repeated generic stock photo. Return a list of records still needing images. The new crawler will hold submissions if it cannot fingerprint existing images, because I require zero duplicate images.

3. Make pending candidate image handling durable. For a supplied authorized official-site image, validate Content-Type and decode the image, enforce a bounded file size, rehost it to existing object storage when permitted, and save the durable URL in image_url. Set PUBLIC_BASE_URL to https://seo-phase.emergent.host and verify the image on both the approval card and the published card. A crawler can verify a remote URL today; it cannot guarantee the source will keep hosting it forever. Rehosting must not bypass blocks or violate image permissions. Keep blocked/unlicensed images in a needs-image state for manual upload rather than publish a broken image.

4. Preserve and expose image_source_url, image_attribution, source_image_url and ideally image_phash/sha256. Add a review checkbox or equivalent for photo-use permission. Do not enable stored Google Maps photo fallback unless provider caching/attribution rules and refresh are explicitly implemented; the new package intentionally uses official-site photos only.

5. Add an authenticated read endpoint for ingestion inventory (name, city, status, image fingerprint/URL, including pending, rejected and published records). Authenticate with a suitably scoped rotated ingestion token. This allows deduplication against the entire queue even if a GitHub Actions cache is lost. The public /api/restaurants endpoint currently covers published records, not a complete queue inventory. GitHub caching is a convenience, not a permanent database.

6. Add server-side perceptual-hash duplicate protection when creating/rehosting/approving an image. Check against all stored images, including manual uploads and rejected/pending cards. Return a structured needs-image reason on collisions rather than approve a reused image. Confirm how missing and legacy unhashable photos are handled.

7. Keep ingestion pending-only and preserve existing name+city deduplication. Confirm price can be unknown/blank without inventing a price level. Continue supporting type=food_truck. Do not silently drop attribution/source fields.

Please deploy these changes, confirm the production base URL, and return a small read-only verification report and any records requiring my manual photo upload. Do not claim image licensing from an attribution field alone.
