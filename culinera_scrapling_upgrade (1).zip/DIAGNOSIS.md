# Why the current Culinera workflow finds nothing new

Checked 1 November 2026 against the public `main` branch of Playboip/culinerascraper.

The live `alberta_culinary_scraper.py` still defines three restaurant records in `raw_data` and loops over those same records. It calls OpenAI to write descriptions and selects generic Unsplash photos from a cuisine dictionary. It makes no Google Places, Yelp or food-news discovery calls. Successful runs can therefore only resubmit the same names; backend duplicate detection then creates zero new records. The imported Yelp secret is not used. The workflow does not pass a Google Places key. The live workflow runs Sundays, not the requested twice-monthly schedule.

The previously delivered API-based replacement is present in the restored local package, but is not the script currently in that public repository. GitHub run history/secret values and private admin records are not accessible here, so this is a diagnosis of deployed source code, not a claim to have inspected every historical run.

## Rebuild plan

1. Replace static discovery with a bounded Scrapling crawl of Alberta food-news and tourism pages, including full articles rather than only RSS headlines.
2. Extract literal venue names with source passages. Cross-check names, province/city, ratings and official presence; do not submit future openings, closures, unverified trucks, chains or ordinary diners.
3. Retain original-copy and real-image gates; record rejected and held leads so zero submissions is explainable rather than a misleading green success.
4. Persist pending submission/image history across GitHub runs, test locally without ingestion, and package the exact repository files plus beginner-friendly installation steps.
5. Keep live submissions to the manual queue on the 1st and 15th only. Do not deploy or ingest in this sandbox without authorized repository access and a securely configured rotated ingestion key.

## Sources

- https://github.com/Playboip/culinerascraper
- https://github.com/d4vinci/Scrapling
- https://scrapling.readthedocs.io/en/latest/fetching/static.html
- https://scrapling.readthedocs.io/en/latest/spiders/getting-started.html
