# Scrapling rebuild: tested results

Checked on 1 November 2026. The replacement is built and tested locally, not installed in the user's GitHub repository. Production ingestion calls in this task: **zero**.

## What the live repository actually runs

The public `main` branch of Playboip/culinerascraper was still at commit `b35c25d`, dated 27 June 2026. Its script loops over three manually entered restaurants and chooses generic Unsplash photos. It performs no opening discovery. Its workflow still runs Sundays, uses Python 3.9 and does not wire a Google Places key. This is why reruns cannot discover new restaurants. Private run history and secret values were not inspected.

## Replacement checks

The final offline suite passed **40 tests**, covering literal extraction, provider identity/review gates, real-new-opening exceptions, exclusion rules, current-feed priority, tourism detail-page priority, image duplicates, complete dry-run flow and unreadable-image holds. Syntax and workflow YAML checks passed. The one workflow has the 1st/15th schedule and preview enabled by default.

Read-only Scrapling checks retrieved current full articles from Only Here for the Food, including its October 26 and October 12, 2026 Food Notes. A one-article live extraction check produced ten literal restaurant/experience leads, including Tesoro Caffe Bar, AJ’s Burgers, Atrium at Sabor, Ugly Dumplings and Bon Arabica Cafe. These are **source leads**, not verified, approved or submitted cards. The report preserves exact supporting quotations.

The all-source access check returned 17 source documents from the initial nine-root configuration. Avenue Calgary returned HTTP 403, which was recorded without bypass. The former Tourism Red Deer root redirected away; it was replaced with the verified `visitreddeer.com` restaurant directory. A separate final check successfully crawled Savour Calgary articles—including `Flower in Bloom`—and Red Deer detail pages for The Hideout and Stock Yard Kitchen. The delivered configuration has ten source roots, eight pages per source, a 90-page overall ceiling and a 900-second crawl time cap.

The current Culinera public API returned 190 published records. A read-only image check could decode/fingerprint one unique image URL and could not retrieve/decode twenty other unique image URLs. That does not prove how every browser will render them, but it prevents complete duplicate comparison. The strict image gate therefore holds new cards until these legacy images are repaired/rehosted or valid fingerprints are available. The discovery report still exposes found leads.

## What was not tested or deployed

No Google/Yelp checks using the user's private keys were executed here. No full production candidate batch was sent. The live one-article AI smoke check used sandbox tooling, not the user's provider account. Unit tests mock verification and ingestion and explicitly prove preview mode makes no POST.

External photos are fetch-time validated; long-term storage and browser-card rendering require the Emergent backend to rehost permitted photos and preserve attribution. Image rights still need editorial confirmation. Perceptual hashes reject detectable duplicates but cannot prove every transformed image is unique. A GitHub cache is not permanent storage; complete queue inventory and server-side image fingerprints are needed for durable cross-run, pending-card protection.

Start with `START_HERE.md`. Send `EMERGENT_IMAGE_AND_HISTORY_REQUEST.md` to Emergent for image cleanup and key rotation before unlocking live submissions.
