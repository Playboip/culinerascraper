# Install the real Scrapling crawler

The script currently on your public GitHub repository still repeats three typed-in venues. This replacement discovers businesses from live website content. It is built and tested locally, but it is not yet installed in your GitHub repository and no cards have been sent to production from this task.

## First: keep the key private

Ask your Emergent agent to rotate the ingestion key you previously shared in chat and update its deployed backend environment. Put the replacement only in GitHub **Secrets**, never in code or another chat message. Your existing Google, Yelp and OpenAI keys can remain in their GitHub Secrets.

## 1. Download and unzip

Download `culinera_scrapling_upgrade.zip` and unzip it. Open the folder named `scraper`. Keep the files together; this version needs its helper modules and `sources.json`, not only the main Python file.

## 2. Replace the root files in GitHub

Open https://github.com/Playboip/culinerascraper and click **Code**.

Click **Add file → Upload files**. Upload these files from the unzipped `scraper` folder directly to the repository root, NOT inside a new folder named `scraper`:

- `alberta_culinary_scraper.py`
- `scrapling_discovery.py`
- `image_guard.py`
- `sources.json`
- `requirements.txt`
- `test_pipeline.py`
- `test_discovery.py`
- `test_source_priority.py`
- `smoke_test.py`
- `README.md`

Scroll down and click **Commit changes**. The new `alberta_culinary_scraper.py` replaces the old file with exactly the same name.

## 3. Replace the ONE workflow

In GitHub, open **.github → workflows → main.yml**. Click the pencil to edit. On your computer, open the package's `WORKFLOW_COPY_PASTE.txt`, select all its text and copy it. In GitHub's editor, select all the old text and paste the entire replacement. Click **Commit changes**.

Do NOT upload a workflow as `main.tml` or place a Python script inside `.github/workflows`. The exact workflow path is `.github/workflows/main.yml`. Keep only one active Culinera discovery workflow; if you see another old `.yml` or `.yaml` file in that folder for the same task, disable that workflow in Actions while replacing it rather than deleting unrelated workflows.

## 4. Check the secrets

Click **Settings → Secrets and variables → Actions → Secrets**. Confirm these repository secrets exist:

1. `INGEST_API_KEY` — the rotated backend key.
2. `GOOGLE_MAPS_API_KEY` — Places API (New), with billing enabled and a key restriction compatible with GitHub-hosted runners.
3. `YELP_API_KEY` — optional second verifier.
4. `OPENAI_API_KEY` — for literal extraction, original descriptions, factual-copy checks and photo relevance.

At least one Google/Yelp verifier is required for a full preview. Having both is preferable. For the crawler-only check below, none of these keys is used. Do not paste secret values into files, workflow logs or messages.

## 5. First run: prove the websites are being crawled

Click **Actions → Culinera Scrapling Discovery → Run workflow**.

Leave **dry_run** checked. Check **discovery_only**. Leave **scan_all_alberta** unchecked. Click the green **Run workflow** button once.

When it finishes, open that run. At the bottom, download the `culinera-scrapling-report-...` artifact and open `culinera_candidates.json`. You should see actual source URLs, article titles, publication dates and article text under `documents`. This run does not call Google, Yelp, OpenAI or the ingestion API. It does not add approval cards—that is intentional.

## 6. Second run: preview verified cards

Run the workflow again. Keep **dry_run** checked, but UNCHECK **discovery_only**. Leave **scan_all_alberta** unchecked for a lower-cost first preview.

Download the new report. Check `discovered_leads`, `held`, `rejected` and `candidates`. A green checkmark only means the workflow finished; `ingestion_result.created` tells you whether anything was actually created. In a preview, created cards are always zero.

If the report says old directory images are unreadable, send `EMERGENT_IMAGE_AND_HISTORY_REQUEST.md` to Emergent before enabling live submissions. The pipeline deliberately holds cards rather than weaken your zero-duplicate-photo requirement. If a provider key/model fails, the run fails with an explanation rather than silently pretending there are no new restaurants.

## 7. Unlock the twice-monthly approval queue

Only after the preview looks right and Emergent has repaired any image blockers, go to **Settings → Secrets and variables → Actions → Variables**. Click **New repository variable**:

Name: `LIVE_SUBMISSIONS_ENABLED`

Value: `true`

For one manual live run, keep **discovery_only** UNCHECKED and UNCHECK **dry_run**. Review any new cards at https://seo-phase.emergent.host/admin. Nothing is auto-published.

The automatic workflow runs on the **1st and 15th at 15:00 UTC**, which is 08:00 or 09:00 in Alberta. GitHub schedules can be delayed; they are not an exact-time guarantee. Until the variable above is true, scheduled runs remain previews.

Do not keep repeatedly running live while troubleshooting. The report explains what is held, and each full preview still uses paid APIs.

## What remains outside the crawler

An official-site photo may work today and be removed tomorrow. Emergent should rehost permitted photos into Culinera's object storage and verify the actual card. Attribution is not permission. This package intentionally does not store Google photo fallback URLs, which can expire and have provider-specific requirements.

GitHub Actions cache preserves prior submissions/image hashes but can be evicted. For strong queue-wide duplicate protection, Emergent must expose an authenticated complete inventory and enforce image hashes server-side. Backend name+city deduplication remains the final safeguard against duplicate restaurant records. See the included Emergent request.

The six articles from the earlier package are unchanged; this upgrade is the discovery crawler, not a claim that those articles were published.
